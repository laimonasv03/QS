public class LoanType implements Comparable{
    private int id;
    private String name;
    private int interestRate;

    public LoanType() {}

    public LoanType(int id, String name, int interestRate){
        if(id < 0 || name == null)
            throw new IllegalArgumentException();
        this.id = id;
        this.name = name;
        this.interestRate = interestRate;
    }
    @Override
    public String toString() {
        return "Item{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", interestRate=" + interestRate +
                '}';
    }


    @Override
    public int compareTo(Object obj) {
        LoanType p = (LoanType) obj;
        return this.name.compareTo(p.name);
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getInterestRate() {
        return interestRate;
    }

    public void setInterestRate(int interestRate) {
        this.interestRate = interestRate;
    }
}
