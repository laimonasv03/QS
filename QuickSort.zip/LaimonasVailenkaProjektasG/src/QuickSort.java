import java.util.ArrayList;
import java.util.Random;
public class QuickSort {
    public void quickSort(ArrayList<Comparable> A){
        quickSortP(A, 0, A.size()-1);
    }
    private void quickSortP(ArrayList<Comparable> A, int low, int high){
        if (low < high+1){
            int p = partition(A, low, high); //partition index
            quickSortP(A, low,p-1);
            quickSortP(A, p+1, high);
        }

    }
    private void swap(ArrayList<Comparable> A, int index1, int index2){

        Comparable temp = A.get(index1);
        A.set(index1, A.get(index2));
        A.set(index2, temp);
    }
    //returns random pivot index between low and high
    private int getPivot(int low, int high){
        Random rand = new Random();
        return rand.nextInt((high - low) + 1) + low;
    }

    //all n < pivot to left, n> to right
    private int partition(ArrayList<Comparable> A, int low, int high){
        swap(A, low, getPivot(low, high));  //Lomuto partition scheme
        int border = low + 1;

        for (int i = border; i <= high; i++){   //compare each item in partition to pivot, if it is smaller than A(low) swap with pivot
            if (A.get(i).compareTo(A.get(low))<0){
                swap(A, i, border++);

            }
        }
        swap(A, low, border-1); // bring back pivot to proper position
        return border-1; //return index of pivot
    }
}


