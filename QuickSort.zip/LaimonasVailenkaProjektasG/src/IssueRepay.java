public class IssueRepay implements Comparable {
    private String date;
    private int loanId;
    private String loanName;
    private int amount;
    private int in_out;



    public IssueRepay(String date, int loanId, int amount, int in_out){
        this.date = date;
        this.loanId = loanId;
        this.amount = amount;
        this.in_out = in_out;
    }

    @Override
    public String toString() {
        return "Item{" +
                "date=" + date +
                ", loanId='" + loanId + '\'' +
                ", loanName='" + loanName +
                ", amount=" + amount +
                ",in_out=" + in_out +
                '}';
    }



    @Override
    public int compareTo(Object obj) {
        IssueRepay other = (IssueRepay) obj;
        if (this.loanName.equals(other.loanName)) {
            if (this.in_out == other.in_out) {
                return 0;
            } else {
                return this.in_out - other.in_out;
            }
        } else {
            return this.loanName.compareTo(other.loanName);
        }
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getLoanId() {
        return loanId;
    }

    public void setLoanId(int loanId) {
        this.loanId = loanId;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getIn_out() {
        return in_out;
    }

    public void setIn_out(int in_out) {
        this.in_out = in_out;
    }

    public String getLoanName() {
        return loanName;
    }

    public void setLoanName(String loanName) {
        this.loanName = loanName;
    }
}
