import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;

//gson version >=2.9.0 is Java 11, and 2.8.6 is Java 8.

public class ReadDataFromJSON {



//    // Read one object of given type
//    public IssueRepay readOneIR(String fileName) {
//        IssueRepay issueRepay = new IssueRepay();
//
//        Gson gson = new Gson();
//
//        try (Reader reader = new FileReader(fileName)) {
//
//            issueRepay = gson.fromJson(reader, IssueRepay.class);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return issueRepay;
//    }
//
//    public LoanType readOneLT(String fileName) {
//        LoanType loanType = new LoanType();
//
//        Gson gson = new Gson();
//
//        try (Reader reader = new FileReader(fileName)) {
//
//            loanType = gson.fromJson(reader, LoanType.class);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return loanType;
//    }
//
//    // read to ArrayList
//    public ArrayList readToArrayList(String fileName) {
//
//        ArrayList arr = new ArrayList();
//
//        Gson gson = new Gson();
//
//        try (Reader reader = new FileReader(fileName)) {
//
//            arr = gson.fromJson(reader, ArrayList.class);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        return arr;
//    }

    // read to HashMap
    public HashMap<Integer,LoanType> readAllILoanTypeToHashMap(String fileName) {

        HashMap<Integer,LoanType> hm = new HashMap();
        Gson gson = new Gson();

        try (Reader reader = new FileReader(fileName)) {

            hm = gson.fromJson(reader, new TypeToken<HashMap<Integer, LoanType>>(){}.getType());

        } catch (IOException e) {
            e.printStackTrace();
        }
        return hm;
    }
    //read to ArrayList
    public ArrayList<IssueRepay> readAllIissueRepayToArray(String fileName) {

        ArrayList<IssueRepay> arr = new ArrayList();

        Gson gson = new Gson();

        try (Reader reader = new FileReader(fileName)) {

            arr = gson.fromJson(reader, new TypeToken<ArrayList<IssueRepay>>(){}.getType());

        } catch (IOException e) {
            e.printStackTrace();
        }
        return arr;
    }
}