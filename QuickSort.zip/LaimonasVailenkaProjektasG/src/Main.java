import java.util.ArrayList;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) {
        //Create Obects
        ReadDataFromJSON dataReader = new ReadDataFromJSON();
        QuickSort srt = new QuickSort();
        Util utility = new Util();

        //read loanType to HashMap
        HashMap<Integer, LoanType> loanTypeHM = dataReader.readAllILoanTypeToHashMap("JSON_files/loanType.json");
        //System.out.println(loanTypeHM);

        //read issueRepay to ArrayList
        ArrayList issueRepayArrayList = dataReader.readAllIissueRepayToArray("JSON_files/issueRepay.json");
        //System.out.println(issueRepayArrayList);

        //issueRepay with names
        ArrayList ir_names = issueRepayArrayList;
        // add loan names to new arr list ir_names;
        utility.findNamesByIdMap(ir_names, loanTypeHM);
        utility.printList(ir_names);

        //sort this bad boy
        srt.quickSort(ir_names);
        utility.printList(ir_names);

        //results of calculations
        utility.Calculate(loanTypeHM,issueRepayArrayList);

    }
}