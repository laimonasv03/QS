
import java.util.ArrayList;
import java.util.HashMap;

public class Util {


    public void Calculate(HashMap<Integer, LoanType> LoanType, ArrayList<IssueRepay> IssueRepay) {
        for (int loanId = 1; loanId <= LoanType.size(); loanId++) {
            int amountIssued = 0;
            int amountRepaid = 0;
            float interestAmount = 0;
            for (IssueRepay issueRepay : IssueRepay) {
                if (issueRepay.getLoanId() == loanId) {
                    if (issueRepay.getIn_out() == -1) {
                        amountIssued += issueRepay.getAmount();
                    } else if (issueRepay.getIn_out() == 1) {
                        amountRepaid += issueRepay.getAmount();
                    } else {
                        throw new IllegalArgumentException("Invalid in_out value: " + issueRepay.getIn_out());
                    }
                }
            }
            interestAmount = (amountIssued * LoanType.get(loanId).getInterestRate()) / 100.0f;
            System.out.println("loanId=" + LoanType.get(loanId).getId() +
                    " loanName=" + LoanType.get(loanId).getName() +
                    " amountIssuedOut=" + amountIssued +
                    " amountRepayedIn=" + amountRepaid +
                    " interestAmount=" + interestAmount);
        }
    }


    public void printList(ArrayList arr) {
        for (Object o : arr) {
            System.out.println(o);
        }



        System.out.println();
    }

    public void printHashMap(HashMap<Integer, LoanType> itemsHM) {
        for (HashMap.Entry entry : itemsHM.entrySet()) {
            System.out.println("itemsHashMap: " + entry.getKey() + ":" + entry.getValue());
        }

        System.out.println();
    }

    // better way to find names of items by id
    public void findNamesByIdMap(ArrayList<IssueRepay> issueRepayArrayList, HashMap<Integer, LoanType> loanTypeHM) {
        for(IssueRepay ir : issueRepayArrayList) {
            int id = ir.getLoanId();
            if(loanTypeHM.containsKey(id)) {
                LoanType p = loanTypeHM.get(id);
                ir.setLoanName(p.getName());
            }
        }
    }
}
